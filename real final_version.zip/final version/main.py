# -*- coding: utf-8 -*-
"""
Created on Wed May 16 15:22:20 2018
@author: zou
"""

import pygame
import time
from pygame.locals import KEYDOWN, K_RIGHT, K_LEFT, K_UP, K_DOWN, K_ESCAPE
from pygame.locals import QUIT

from game import Game
from krusty import NGame, no_endGame
from burger import burger_Game, Settings
black = pygame.Color(0, 0, 0)
white = pygame.Color(255, 255, 255)

green = pygame.Color(0, 200, 0)
bright_green = pygame.Color(0, 255, 0)
red = pygame.Color(200, 0, 0)
bright_red = pygame.Color(255, 0, 0)
blue = pygame.Color(32, 178, 170)
bright_blue = pygame.Color(32, 200, 200)
yellow = pygame.Color(255, 205, 0)
bright_yellow = pygame.Color(255, 255, 0)
orange = ( 255 , 100 , 10 )
cyan = (0, 255, 255) # more colours, shukun yu
mage = (255, 0, 255)
pink = ( 255 , 100 , 180 )

x = 0
game = Game()
ngame = NGame()
no_end = no_endGame()
burger = burger_Game()
rect_len = game.settings.rect_len
big_len = burger.settings.rect_len
snake = ngame.snake
# normal game snake, shukun
snake1 = game.snake1
#twin snake with snake 2, shukun
snake2 = game.snake2
snake4 = no_end.snake
# no end game snake shukun
snake5 = burger.snake
# a special mode with large screen, zhou qi jun
pygame.init()
fpsClock = pygame.time.Clock()
screen = pygame.display.set_mode((game.settings.width * 15, game.settings.height * 15))
pygame.display.set_caption('Gluttonous')

image_joker = pygame.image.load('images/joker.bmp') #image needed for background, zqj
image_faiz = pygame.image.load('images/faiz.bmp')
'''
crash_sound = pygame.mixer.Sound('./sound/crash.wav')

def text_objects(text, font, color=black):
    text_surface = font.render(text, True, color)
    return text_surface, text_surface.get_rect()


def message_display(text, x, y, color=black):
    large_text = pygame.font.SysFont('comicsansms', 50)
    text_surf, text_rect = text_objects(text, large_text, color)
    text_rect.center = (x, y)
    screen.blit(text_surf, text_rect)
    pygame.display.update()


def button(msg, x, y, w, h, inactive_color, active_color, action=None, parameter=None):
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    if x + w > mouse[0] > x and y + h > mouse[1] > y:
        pygame.draw.rect(screen, active_color, (x, y, w, h))
        if click[0] == 1 and action != None:
            if parameter != None:
                action(parameter)
            else:
                action()
    else:
        pygame.draw.rect(screen, inactive_color, (x, y, w, h))

    smallText = pygame.font.SysFont('comicsansms', 20)
    TextSurf, TextRect = text_objects(msg, smallText)
    TextRect.center = (x + (w / 2), y + (h / 2))
    screen.blit(TextSurf, TextRect)


def quitgame():
    pygame.quit()
    quit()


def crash():
    pygame.mixer.Sound.play(crash_sound)
    message_display('crashed', game.settings.width / 2 * 15, game.settings.height / 3 * 15, white)
    time.sleep(1)
'''
crash_sound = pygame.mixer.Sound('./sound/Tom.wav')

pygame.mixer.music.load('./sound/lawrence.wav')#background music, zhou qijun
pygame.mixer.music.play(-1,0)
pygame.mixer.music.set_volume(0.5)

def text_objects(text, font, color=black):#color of button, zqj
    text_surface = font.render(text, True, color)
    return text_surface, text_surface.get_rect()


def message_display(text, x, y, color=bright_blue):
    large_text = pygame.font.SysFont('mvboli', 50)#type and size of text zqj
    text_surf, text_rect = text_objects(text, large_text, color)
    text_rect.center = (x, y)
    screen.blit(text_surf, text_rect)
    pygame.display.update()

def text_display(text, x, y, color=bright_blue): # text created for reason, presenting message with smaller words and white background, shukun yu
    large_text = pygame.font.SysFont('mvboli', 20)
    text_surf, text_rect = text_objects(text, large_text, color)
    text_rect.center = (x, y)
    screen.fill(white)
    screen.blit(text_surf, text_rect)
    pygame.display.update()

def button(msg, x, y, w, h, inactive_color, active_color, action=None, parameter=None):
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    if x + w > mouse[0] > x and y + h > mouse[1] > y:
        pygame.draw.rect(screen, active_color, (x, y, w, h))
        if click[0] == 1 and action != None:
            if parameter != None:
                action(parameter)
            else:
                action()
    else:
        pygame.draw.rect(screen, inactive_color, (x, y, w, h))

    smallText = pygame.font.SysFont('mvboli', 20) #type and size of text, zqj
    TextSurf, TextRect = text_objects(msg, smallText)
    TextRect.center = (x + (w / 2), y + (h / 2))
    screen.blit(TextSurf, TextRect)


def quitgame():
    pygame.quit()
    quit()


def crash():
    pygame.mixer.Sound.play(crash_sound)
    message_display('crashed', game.settings.width / 2 * 15, game.settings.height / 3 * 15, blue) #crash font color, zqj
    time.sleep(2)#time to wait after get crashed


def initial_interface():
    intro = True

    while intro:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()

        screen.blit(image_joker, (-10, 0))  # background, zqj

        message_display('Gluttonous', game.settings.width / 2 * 15, game.settings.height / 4 * 15)
        button('Go!', 80, 240, 80, 40, green, bright_green, game_loop, 'human')# normal play button,
        button('twins!', 80, 300, 80, 40, blue, bright_blue, dgame_loop, 'human') #button for twin snake,shukunyu
        button('HARD', 175, 240, 80, 40, yellow, bright_yellow, hard_game_loop,'human') # hard mode
        button('BAILOUT!', 270, 300, 80, 40, pink, cyan, rgame_loop, 'human')# button for the no end game snake no die, shukun
        button('Quit', 270, 240, 80, 40, red, bright_red, quitgame)# quit button
        button('glhf', 175, 300, 80, 40, orange, orange, bgame_loop, 'human') # button for the big screen game., zqj

        pygame.display.update()
        pygame.time.Clock().tick(15)

def game_loop(player, fps=10):
    ngame.restart_game()

    while not ngame.game_end():

        pygame.event.pump()

        move = krusty_human_move()
        fps = 5

        ngame.do_move(move)

        screen.fill(black)

        ngame.snake.blit(rect_len, screen)
        ngame.strawberry.blit(screen)
        ngame.blit_score(white, screen)

        pygame.display.flip()

        fpsClock.tick(fps)

    crash()
def bcrash():
    pygame.mixer.Sound.play(crash_sound)
    message_display("crashed", burger.setting.width /2 *15, burger.settings.height/3*15 , blue) #crash font colour, zqj
    time.sleep(2) # time to wait after crash
def bgame_loop(player, fps=10):
    burger.restart_game()
    #giving players instruction as bgame has a bigger screen and need to be centralised,  Shukun Yu
    text_display("please place the window to top left corner.", game.settings.width / 2 * 15, game.settings.height / 4 * 15, red)
    #giving players time to respond, Shukun yu
    time.sleep(5)
    screen = pygame.display.set_mode((burger.settings.width * 15, burger.settings.height * 15))

    while not burger.game_end():

        pygame.event.pump()

        move = buger_human_move()
        fps = 15 #'speed' of snake, zqj faster speed because big map

        burger.do_move(move)

        screen.blit(image_faiz,(-20,-35))#background

        burger.snake.blit(big_len, screen)
        burger.strawberry.blit(screen)
        burger.blit_score(blue, screen)#color of score font
        burger.blit_extra_chance(blue,screen)

        pygame.display.flip()

        fpsClock.tick(fps)
    bcrash()
    screen = pygame.display.set_mode((game.settings.width * 15, game.settings.height * 15))

    #getting back to the orignal screen to adapt all modes, Shukun yu

def hard_game_loop(player, fps=20): #twice faster speed in the harder mode, sharing the same snake with nromal mode, shukun yu
    ngame.restart_game()

    while not ngame.game_end():
        pygame.event.pump()

        move = krusty_human_move()
        fps = 10

        ngame.do_move(move)

        screen.fill(black)

        ngame.snake.blit(rect_len, screen)
        ngame.strawberry.blit(screen)
        ngame.blit_score(white, screen)

        pygame.display.flip()

        fpsClock.tick(fps)

    crash()

def rgame_loop(player, fps=20): #endless game with game of no end using the no_end from krusty.py, also twice speed shukun yu
    no_end.restart_game()
    while not no_end.game_end():

        pygame.event.pump()

        move = no_end_human_move()
        fps = 10

        no_end.do_move(move)

        screen.fill(black)

        no_end.snake.blit(rect_len, screen)
        no_end.strawberry.blit(screen)
        no_end.blit_score(white, screen)

        pygame.display.flip()

        fpsClock.tick(fps)

    crash()

def dgame_loop(player, fps=10): #dgame is the double snake game with two snake going opposite directions using game from game.py, Shukun yu
    game.restart_game()

    while not game.game_end():

        pygame.event.pump()

        move = human_move()
        fps = 5

        game.do_move(move)

        screen.fill(black)

        game.snake1.blit(rect_len, screen)
        game.snake2.blit(rect_len, screen)
        game.strawberry.blit(screen)
        game.blit_score(white, screen)

        pygame.display.flip()

        fpsClock.tick(fps)

    crash()


def human_move(): #because lots of modes are added so multiple human modes are needed, shukun yu
    direction = snake1.facing #direction of snake 1 is == direction snake 2 (opposite)(TWIN SNAKE), shukun yu
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()

        elif event.type == KEYDOWN:
            if event.key == K_RIGHT or event.key == ord('d'):
                direction = 'right'
            if event.key == K_LEFT or event.key == ord('a'):
                direction = 'left'
            if event.key == K_UP or event.key == ord('w'):
                direction = 'up'
            if event.key == K_DOWN or event.key == ord('s'):
                direction = 'down'
            if event.key == K_ESCAPE:
                pygame.event.post(pygame.event.Event(QUIT))

    move = game.direction_to_int(direction)

    return move

def krusty_human_move(): #move controlling snake5 (BIG SCREEN), zqj
    direction = snake.facing

    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()

        elif event.type == KEYDOWN:
            if event.key == K_RIGHT or event.key == ord('d'):
                direction = 'right'
            if event.key == K_LEFT or event.key == ord('a'):
                direction = 'left'
            if event.key == K_UP or event.key == ord('w'):
                direction = 'up'
            if event.key == K_DOWN or event.key == ord('s'):
                direction = 'down'
            if event.key == K_ESCAPE:
                pygame.event.post(pygame.event.Event(QUIT))

    move = ngame.direction_to_int(direction)

    return move

def no_end_human_move(): #control snake 4 (no dieing snake), shukun yu
    direction = snake4.facing

    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()

        elif event.type == KEYDOWN:
            if event.key == K_RIGHT or event.key == ord('d'):
                direction = 'right'
            if event.key == K_LEFT or event.key == ord('a'):
                direction = 'left'
            if event.key == K_UP or event.key == ord('w'):
                direction = 'up'
            if event.key == K_DOWN or event.key == ord('s'):
                direction = 'down'
            if event.key == K_ESCAPE:
                pygame.event.post(pygame.event.Event(QUIT))

    move = no_end.direction_to_int(direction)

    return move
def buger_human_move(): #control snake (basic one), shukun yu
    direction = snake5.facing

    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()

        elif event.type == KEYDOWN:
            if event.key == K_RIGHT or event.key == ord('d'):
                direction = 'right'
            if event.key == K_LEFT or event.key == ord('a'):
                direction = 'left'
            if event.key == K_UP or event.key == ord('w'):
                direction = 'up'
            if event.key == K_DOWN or event.key == ord('s'):
                direction = 'down'
            if event.key == K_ESCAPE:
                pygame.event.post(pygame.event.Event(QUIT))

    move = burger.direction_to_int(direction)

    return move
if __name__ == "__main__":
    initial_interface()


